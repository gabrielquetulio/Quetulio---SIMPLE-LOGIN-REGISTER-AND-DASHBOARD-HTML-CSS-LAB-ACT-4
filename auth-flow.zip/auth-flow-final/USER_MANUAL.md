# User Manual

A short guide on how to use the Login / Register / Dashboard pages.

## 1. Opening the Application

1. Locate the project folder on your computer.
2. Double-click `login.html`, or right-click it and choose **Open with → your browser** (Chrome, Edge, Firefox, etc.).
3. The **Login page** will load first.

## 2. Creating a New Account

1. On the Login page, click **"Register here"** at the bottom of the card.
2. You'll be taken to the **Register page**.
3. Fill in all fields:
   - **Full Name** — your first and last name
   - **Username** — the name you'll log in with
   - **Email** — a valid email address
   - **Password** — your chosen password
   - **Confirm Password** — must match the Password field
4. Click the **Register** button.
5. You'll be redirected back to the **Login page** to sign in with your new account.

> Note: Since this is a front-end-only demo, no account data is actually saved. The Register button simply demonstrates the sign-up → login flow.

## 3. Logging In

1. On the Login page, enter any **Username** and **Password** (all fields are required, but not validated against a database).
2. Click the **Login** button.
3. You'll be taken to the **Dashboard page**.

## 4. Using the Dashboard

- The Dashboard shows a welcome message and a few summary boxes (account status, last login, etc.).
- To leave the Dashboard, click **Log out** in the top-right corner of the navigation bar. This returns you to the Login page.

## 5. Navigation Summary

| From | Action | Goes To |
|---|---|---|
| Login page | Click "Login" | Dashboard |
| Login page | Click "Register here" | Register page |
| Register page | Click "Register" | Login page |
| Register page | Click "Login here" | Login page |
| Dashboard | Click "Log out" | Login page |

## 6. Troubleshooting

- **Page looks unstyled:** Make sure `style.css` is in the same folder as the HTML files — it's linked by relative path.
- **Links don't work:** Confirm all files (`login.html`, `register.html`, `dashboard.html`, `style.css`) are in the same folder and haven't been renamed.
